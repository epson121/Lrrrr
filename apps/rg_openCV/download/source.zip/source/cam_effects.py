import numpy as np
import cv2
from itertools import cycle

# postavljanje izvora videa
# arg1 -> id kamere
cap = cv2.VideoCapture(0)

# postavljanje pocetne vrijednosti varijable func
func = 4
while(True):
    # dohvacanje slika (frame po frame)
    ret, frame = cap.read()

    # operacije nad frameovima
    if func == 0:
    	frm = cv2.Laplacian(frame,cv2.CV_64F)
    elif func == 1:
    	frm = cv2.GaussianBlur(frame,(0,0),5)
    elif func == 2:
    	frm = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    elif func == 3:
    	frm = cv2.Canny(frame, 5, 100)
    else:
    	frm = cv2.cvtColor(frame, 0)


    # prikaz konacnog framea
    cv2.imshow('frame',frm)

    #dohvacanje tipke i promjena func varijable te postavljanje efekta
    key = cv2.waitKey(1)
    if key == 27:
    	break
    if key == ord('a'):
    	print func
    	func = 1
    if key == ord('s'):
    	func = 0
    if key == ord('d'):
    	func = 2
    if key == ord('f'):
    	func = 3

# cleanup i gasenje prozora
cap.release()
cv2.destroyAllWindows()