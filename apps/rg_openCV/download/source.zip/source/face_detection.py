import numpy as np
import cv2

# ucitavanje xml datoteke sa "trening podacima" za prepoznavanje lica
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
# ucitavanje xml datoteke sa "trening podacima" za prepoznavanje oka
eye_cascade = cv2.CascadeClassifier('haarcascade_eye.xml')

# ucitavanje slike
img = cv2.imread('people.jpg')

#kreiranje crno-bijele slike
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# detektira objekte (lica) razlicitih velicina sa slike (vraca listu objekata)
faces = face_cascade.detectMultiScale(gray, 1.3, 5)

#petlja kroz objekte
for (x,y,w,h) in faces:
    # oznacavanje lica kvadratom
    cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
    roi_gray = gray[y:y+h, x:x+w]
    roi_color = img[y:y+h, x:x+w]

    # nad svakim licem detektira objekte koji imaju oblik "ociju"
    eyes = eye_cascade.detectMultiScale(roi_gray)

    # petlja kroz listu objekata oka
    for (ex,ey,ew,eh) in eyes:
        # oznacavanje oka kvadratom
        cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(0,255,0),2)

while True:
    # prikaz slike
	cv2.imshow('img',img)

    #na tipku ESC gasi program
	key = cv2.waitKey(0)
	if key == 27:
		break;
cv2.destroyAllWindows()