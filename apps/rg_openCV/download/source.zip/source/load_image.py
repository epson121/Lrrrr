import numpy as np
import cv2

# Load a color image in grayscale
# @args1 - image path
# @args2 - flag (way image should be read)
#		 -  1 -> normal, coloured, no transparency
#		 -  0 -> grayscale
#		 - -1 -> normal, coloured + transparency
img = cv2.imread('sheep.png',0)

while(True):
	# show the image
	cv2.imshow('image',img)
	# wait for the keypress (0 -> indefinitely)
	key = cv2.waitKey(0)
	# of key is ESC, break
	if key == 27:
		break
# destroy all windows (cleanup)
cv2.destroyAllWindows()